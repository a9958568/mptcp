#!/bin/sh
cp mptcp.list /etc/apt/sources.list.d/
wget -q -O - http://multipath-tcp.org/mptcp.gpg.key | sudo apt-key add - 
apt-get update
apt-get install -y linux-mptcp 
apt-get install -y wireshark 
apt-get install -y iperf 
apt-get install -y knemo 
reboot


