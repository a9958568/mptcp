#!/bin/sh
cp mptcp_down /etc/network/if-post-down.d/
cp mptcp_up /etc/network/if-up.d/
apt-get upgrade
cp knemorc /usr/share/kde4/config/
apt-get install flex -y
apt-get install bison -y
apt-get install libdb-dev -y
cd iproute-mptcp-mptcp_v0.89
make 
make install
cd
cd /etc/network/if-post-down.d/
chmod 777 mptcp_down
./mptcp_down
cd ..
cd if-up.d/
chmod 777 mptcp_up
./mptcp_up




